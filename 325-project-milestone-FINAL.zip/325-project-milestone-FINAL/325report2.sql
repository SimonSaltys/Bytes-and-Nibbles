-- Bytes-and-Nibbles
-- CS 325 - Fall 2023
-- 12/11/23
-- Names: Natalie Oulman, Simon Saltikov, Shawn Zereh, Aidan Sevillia, Brian Pinkernell, Griffin Jarrell-Desch

spool 325report2-results.txt

-- Monthly Sales Report 
-- This report shows monthly sales figures, including total sales, the number of orders, and the average order value per month. It's useful for financial reporting and business performance analysis.

clear breaks columns computes
ttitle 'Monthly Sales Report'
btitle 'Bytes-and-Nibbles LLC'
set pagesize 25
set linesize 75
set feedback off

column Month heading 'Date|Time' format A25
column Total_Orders heading 'Total|Orders' format 999
column Total_Sales heading 'Total|Sales' format $999.99
column Average_Order_Value heading 'Average|Order|Value' format $999.99


BREAK ON Month SKIP 1 ON REPORT
COMPUTE SUM OF Total_Sales ON Month 
COMPUTE AVG OF Average_Order_Value ON Month

SELECT 
    TO_CHAR(co.date_received) AS Month,
    COUNT(co.order_id_num) AS Total_Orders,
    SUM(tc.price * io.item_quantity) AS Total_Sales,
    ROUND(AVG(tc.price * io.item_quantity), 2) AS Average_Order_Value
FROM 
    customer_order co, items_in_order io, treat_catalog tc
WHERE 
    co.order_id_num = io.order_id_num AND 
    io.item_id_num = tc.item_id_num
GROUP BY 
    TO_CHAR(co.date_received)
ORDER BY 
    Month;



spool off;

clear breaks columns computes
set feedback on
set pagesize 14
set linesize 80
ttitle off
btitle off
