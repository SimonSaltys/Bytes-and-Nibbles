-- Bytes-and-Nibbles
-- CS 325 - Fall 2023
-- 12/11/23
-- Names: Natalie Oulman, Simon Saltikov, Shawn Zereh, Aidan Sevillia, Brian Pinkernell, Griffin Jarrell-Desch

spool 325report1-results.txt

--  Customer Order Summary
--  This report provides a summary of customer orders. It displays the total amount spent and the total number of items ordered by each customer. The report is useful for understanding customer buying habits and for marketing analysis.

clear breaks columns computes
ttitle 'Customer Order Summary'
btitle 'Bytes-and-Nibbles LLC'
set pagesize 40
set linesize 75
set feedback off


column Customer_Name heading 'Customer|Name' format A15
column Total_Orders heading 'Total|Orders' format 999
column Total_Amount_Spent heading 'Total|Amount|Spent' format $999.99
column Total_Items_Ordered heading 'Total|Items|Ordered' format 999
BREAK ON Customer_Name SKIP 1 ON REPORT
COMPUTE SUM OF Total_Amount_Spent, Total_Items_Ordered ON Customer_Name

SELECT 
    u.fname || ' ' || u.lname AS Customer_Name,
    COUNT(DISTINCT co.order_id_num) AS Total_Orders,
    SUM(tc.price * io.item_quantity) AS Total_Amount_Spent,
    SUM(io.item_quantity) AS Total_Items_Ordered
FROM 
    user_account u, customer_order co, items_in_order io, treat_catalog tc
WHERE 
    u.user_id = co.user_id AND 
    co.order_id_num = io.order_id_num AND 
    io.item_id_num = tc.item_id_num
GROUP BY 
    u.fname, u.lname
ORDER BY 
    Total_Amount_Spent DESC;


spool off;

clear breaks columns computes
set feedback on
set pagesize 14
set linesize 80
ttitle off
btitle off

